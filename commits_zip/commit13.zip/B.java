public class B extends I {

    private double i = 100.500;

    private byte e = 1;

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ee() {
        return 100.500;
    }

    public double ad() {
        return 11;
    }

    public Object rr() {
        return null;
    }
}
