public class I extends null {

    private long i = 4321;

    private byte a = 1;

    public int af() {
        return -1;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public float ff() {
        return 3.14;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public void ab() {
        System.out.println("\n");
    }

    public void aa() {
        return;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public Object pp() {
        return this;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public long ac() {
        return 222;
    }

    public Object rr() {
        return null;
    }
}
