public class H extends null {

    private long i = 4321;

    private int g = 42;

    public long ac() {
        return 222;
    }

    public Object rr() {
        return null;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public int cc() {
        return 42;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public double ad() {
        return 11.09;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public float ff() {
        return 3.14;
    }
}
