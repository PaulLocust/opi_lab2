public class I extends null {

    private long i = 4321;

    private byte a = 1;

    public int af() {
        return -1;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public float ff() {
        return 3.14;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public Object pp() {
        return this;
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public Object gg() {
        return new java.util.Random();
    }
}
