public class D {

    private double b = 100.500;

    private double i = 100.500;

    public long dd() {
        return 88888;
    }

    public void aa() {
        return;
    }
}
