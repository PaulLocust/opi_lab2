public class H {

    private long i = 4321;

    private int g = 42;

    public long ac() {
        return 222;
    }

    public Object rr() {
        return null;
    }
}
