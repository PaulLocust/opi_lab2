public class B extends I {

    private double i = 100.500;

    private byte e = 1;

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ee() {
        return java.lang.Math.PI;
    }

    public double ad() {
        return 11;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public Object rr() {
        return null;
    }

    public int ae() {
        return 8;
    }

    public float ff() {
        return 0;
    }

    public String kk() {
        return "Yes";
    }

    public long dd() {
        return 33;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public void aa() {
        System.out.println("void aa");
    }

    public Object pp() {
        return this;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }
}
