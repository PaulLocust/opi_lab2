public class I extends null {

    private long i = 4321;

    private byte a = 1;

    public int af() {
        return -1;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public byte oo() {
        return 4;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public float ff() {
        return 3.14;
    }

    public Object rr() {
        return null;
    }

    public double ad() {
        return 11;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public long ac() {
        return 222;
    }

    public long dd() {
        return 100500;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public double ee() {
        return 100.500;
    }

    public void aa() {
        return;
    }

    public int cc() {
        return 39;
    }

    public Object gg() {
        return new java.util.Random();
    }
}
