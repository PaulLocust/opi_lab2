public class D extends null {

    private double b = 100.500;

    private double i = 100.500;

    public long dd() {
        return 99999;
    }

    public void aa() {
        return;
    }

    public void ab() {
        System.out.println("\n");
    }

    public int af() {
        return -1;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public float ff() {
        return 3.14;
    }

    public int cc() {
        return 13;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public Object pp() {
        return this;
    }

    public String kk() {
        return "Yes";
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public Object rr() {
        return null;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public long ac() {
        return 333;
    }

    public double ad() {
        return 11.09;
    }
}
