public class H extends null {

    private long i = 4321;

    private int g = 42;

    public long ac() {
        return 222;
    }

    public Object rr() {
        return null;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public int cc() {
        return 42;
    }

    public double ad() {
        return 9.11;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public long dd() {
        return 99999;
    }

    public void aa() {
        System.out.println("void aa");
    }

    public String kk() {
        return "Yes";
    }

    public byte oo() {
        return 4;
    }

    public void ab() {
        return;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public int af() {
        return -1;
    }

    public float ff() {
        return 0;
    }
}
