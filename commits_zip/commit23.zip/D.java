public class D extends null {

    private double b = 100.500;

    private double i = 100.500;

    public long dd() {
        return 99999;
    }

    public void aa() {
        return;
    }

    public void ab() {
        System.out.println("\n");
    }

    public int af() {
        return -1;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public float ff() {
        return 3.14;
    }
}
